
from django.shortcuts import render, redirect
from .models import DailyWork
from django.contrib import messages

def daily_work_form(request):
    if request.method == 'POST':
        DailyWork.objects.create(
            teacher_name=request.POST['teacher_name'],
            teacher_id=request.POST['teacher_id'],
            class_taken=request.POST['class_taken'],
            period_1=request.POST.get('period_1', ''),
            period_2=request.POST.get('period_2', ''),
            period_3=request.POST.get('period_3', ''),
            period_4=request.POST.get('period_4', ''),
            period_5=request.POST.get('period_5', ''),
            period_6=request.POST.get('period_6', ''),
            period_7=request.POST.get('period_7', ''),
            period_8=request.POST.get('period_8', ''),
        )
        messages.success(request, "Daily work submitted successfully.")
        return redirect('daily_work')  # reload same form

    return render(request, 'Routine/r1.html')


def r1(request):
    return render(request,'Routine/r1.html')





# views.py

from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login
from django.contrib import messages
from django.contrib.auth.models import User  # or your CustomUser model
from django.views.decorators.csrf import csrf_protect

@csrf_protect
def login_view(request):
    if request.method == 'POST':
        email = request.POST.get('email')
        password = request.POST.get('password')
        role = request.POST.get('role')

        try:
            # Assuming username is the email
            user = User.objects.get(email=email)

            if user.check_password(password) and hasattr(user, 'role') and user.role == role:
                login(request, user)
                if role == 'teacher':
                    return redirect('teacher_dashboard')
                else:
                    return redirect('student_dashboard')
            else:
                messages.error(request, "Invalid credentials or role.")
        except User.DoesNotExist:
            messages.error(request, "User does not exist.")

    return render(request, 'login.html')

