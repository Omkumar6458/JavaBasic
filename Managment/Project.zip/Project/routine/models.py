
from django.db import models

class DailyWork(models.Model):
    teacher_name = models.CharField(max_length=100)
    teacher_id = models.CharField(max_length=20)
    class_taken = models.CharField(max_length=20)
    period_1 = models.CharField(max_length=100, blank=True)
    period_2 = models.CharField(max_length=100, blank=True)
    period_3 = models.CharField(max_length=100, blank=True)
    period_4 = models.CharField(max_length=100, blank=True)
    period_5 = models.CharField(max_length=100, blank=True)
    period_6 = models.CharField(max_length=100, blank=True)
    period_7 = models.CharField(max_length=100, blank=True)
    period_8 = models.CharField(max_length=100, blank=True)
    submitted_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.teacher_name} - {self.submitted_at.date()}"



