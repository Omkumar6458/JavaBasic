
from django.urls import path

from.import views

urlpatterns = [

path('daily-work/', views.daily_work_form, name='daily_work'),
path('r1',views.r1,name='r1'),
  
]




