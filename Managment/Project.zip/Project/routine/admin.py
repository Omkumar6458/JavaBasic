from django.contrib import admin
from .models import DailyWork

@admin.register(DailyWork)
class DailyWorkAdmin(admin.ModelAdmin):
    list_display = [field.name for field in DailyWork._meta.fields] 

