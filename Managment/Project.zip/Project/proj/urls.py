from django.urls import path,include
from.import views

urlpatterns=[
  path('',views.demo,name='index'),
  path('i/',views.block,name='index1'),
  path('dash/',views.dashboard, name='dashboard'),
  path('notification/mark-as-read/', views.mark_notification_as_read, name='mark_notification_as_read' ),
  path('notification/clear-all', views.clear_all_notification, name= "clear_all_notification"),
  path('holiday/',views.holiday, name='holiday'),
  path('fee/',views.fee,name='fee'),
  path('teacher/',views.teacher, name='teacher'),
  path('o1/',views.personal, name ='personal'),
  path(' ',views.log, name='log'),
  
 
 

]
