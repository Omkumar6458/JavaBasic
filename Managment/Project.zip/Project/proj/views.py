from django.shortcuts import render
from django.http import HttpResponse
from django.shortcuts import render
from django.http import JsonResponse
from .models import Notification





# Create your views here.
def demo(request):
  return render(request,'authentication/login.html')

def block(request):
  return render(request,'Home/base1.html')


def dashboard(request):
  return render(request,"students/student-dashboard.html")

def mark_notification_as_read(request):
    if request.method == 'POST':
        notification = Notification.objects.filter(user=request.user, is_read=False)
        notification.update(is_read=True)
        return JsonResponse({'status': 'success'})
    return HttpResponseForbidden()

def clear_all_notification(request):
    if request.method == "POST":
        notification = Notification.objects.filter(user=request.user)
        notification.delete()
        return JsonResponse({'status': 'success'})
    return HttpResponseForbidden()



def holiday(request):
   return render(request, 'other/Holiday.html')

def fee(request):
   return render(request,'other/fee.html')

def teacher(request):
   return render(request,'other/teacher.html')

def personal(request):
   return render(request,'other/personal.html')



def log(request):
   return render(request,'Routine/l.html')